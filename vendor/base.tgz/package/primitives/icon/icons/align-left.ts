// Auto-generated from lucide-static — do not edit
export const alignLeft = `<path d="M21 5H3" />
<path d="M15 12H3" />
<path d="M17 19H3" />`;
