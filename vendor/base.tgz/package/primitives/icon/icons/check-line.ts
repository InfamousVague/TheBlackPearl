// Auto-generated from lucide-static — do not edit
export const checkLine = `<path d="M20 4L9 15" />
<path d="M21 19L3 19" />
<path d="M9 15L4 10" />`;
