// Auto-generated from lucide-static — do not edit
export const baseline = `<path d="M4 20h16" />
<path d="m6 16 6-12 6 12" />
<path d="M8 12h8" />`;
