// Auto-generated from lucide-static — do not edit
export const arrowLeftRight = `<path d="M8 3 4 7l4 4" />
<path d="M4 7h16" />
<path d="m16 21 4-4-4-4" />
<path d="M20 17H4" />`;
