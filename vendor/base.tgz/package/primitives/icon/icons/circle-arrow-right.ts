// Auto-generated from lucide-static — do not edit
export const circleArrowRight = `<circle cx="12" cy="12" r="10" />
<path d="m12 16 4-4-4-4" />
<path d="M8 12h8" />`;
