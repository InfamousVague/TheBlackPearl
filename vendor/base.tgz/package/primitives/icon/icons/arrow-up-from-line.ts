// Auto-generated from lucide-static — do not edit
export const arrowUpFromLine = `<path d="m18 9-6-6-6 6" />
<path d="M12 3v14" />
<path d="M5 21h14" />`;
