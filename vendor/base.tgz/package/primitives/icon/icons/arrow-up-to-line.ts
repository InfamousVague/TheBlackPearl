// Auto-generated from lucide-static — do not edit
export const arrowUpToLine = `<path d="M5 3h14" />
<path d="m18 13-6-6-6 6" />
<path d="M12 7v14" />`;
