// Auto-generated from lucide-static — do not edit
export const alignHorizontalSpaceBetween = `<rect width="6" height="14" x="3" y="5" rx="2" />
<rect width="6" height="10" x="15" y="7" rx="2" />
<path d="M3 2v20" />
<path d="M21 2v20" />`;
