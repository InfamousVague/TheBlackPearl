// Auto-generated from lucide-static — do not edit
export const arrowDownCircle = `<circle cx="12" cy="12" r="10" />
<path d="M12 8v8" />
<path d="m8 12 4 4 4-4" />`;
