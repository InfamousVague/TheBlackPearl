// Auto-generated from lucide-static — do not edit
export const blend = `<circle cx="9" cy="9" r="7" />
<circle cx="15" cy="15" r="7" />`;
