// Auto-generated from lucide-static — do not edit
export const arrowLeft = `<path d="m12 19-7-7 7-7" />
<path d="M19 12H5" />`;
