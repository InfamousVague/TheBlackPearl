// Auto-generated from lucide-static — do not edit
export const chevronUpCircle = `<circle cx="12" cy="12" r="10" />
<path d="m8 14 4-4 4 4" />`;
