// Auto-generated from lucide-static — do not edit
export const caseLower = `<path d="M10 9v7" />
<path d="M14 6v10" />
<circle cx="17.5" cy="12.5" r="3.5" />
<circle cx="6.5" cy="12.5" r="3.5" />`;
