// Auto-generated from lucide-static — do not edit
export const arrowDownUp = `<path d="m3 16 4 4 4-4" />
<path d="M7 20V4" />
<path d="m21 8-4-4-4 4" />
<path d="M17 4v16" />`;
