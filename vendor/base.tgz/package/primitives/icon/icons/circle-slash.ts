// Auto-generated from lucide-static — do not edit
export const circleSlash = `<circle cx="12" cy="12" r="10" />
<line x1="9" x2="15" y1="15" y2="9" />`;
