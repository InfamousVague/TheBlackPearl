// Auto-generated from lucide-static — do not edit
export const airplay = `<path d="M5 17H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-1" />
<path d="m12 15 5 6H7Z" />`;
