// Auto-generated from lucide-static — do not edit
export const arrowUpLeftSquare = `<rect width="18" height="18" x="3" y="3" rx="2" />
<path d="M8 16V8h8" />
<path d="M16 16 8 8" />`;
