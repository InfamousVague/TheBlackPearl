// Auto-generated from lucide-static — do not edit
export const arrowsUpFromLine = `<path d="m4 6 3-3 3 3" />
<path d="M7 17V3" />
<path d="m14 6 3-3 3 3" />
<path d="M17 17V3" />
<path d="M4 21h16" />`;
