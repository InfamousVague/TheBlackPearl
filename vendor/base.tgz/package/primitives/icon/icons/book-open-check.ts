// Auto-generated from lucide-static — do not edit
export const bookOpenCheck = `<path d="M12 21V7" />
<path d="m16 12 2 2 4-4" />
<path d="M22 6V4a1 1 0 0 0-1-1h-5a4 4 0 0 0-4 4 4 4 0 0 0-4-4H3a1 1 0 0 0-1 1v13a1 1 0 0 0 1 1h6a3 3 0 0 1 3 3 3 3 0 0 1 3-3h6a1 1 0 0 0 1-1v-1.3" />`;
