// Auto-generated from lucide-static — do not edit
export const arrowUpFromDot = `<path d="m5 9 7-7 7 7" />
<path d="M12 16V2" />
<circle cx="12" cy="21" r="1" />`;
