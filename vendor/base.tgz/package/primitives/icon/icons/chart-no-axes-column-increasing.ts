// Auto-generated from lucide-static — do not edit
export const chartNoAxesColumnIncreasing = `<path d="M5 21v-6" />
<path d="M12 21V9" />
<path d="M19 21V3" />`;
