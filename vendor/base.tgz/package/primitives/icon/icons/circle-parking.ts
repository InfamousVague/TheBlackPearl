// Auto-generated from lucide-static — do not edit
export const circleParking = `<circle cx="12" cy="12" r="10" />
<path d="M9 17V7h4a3 3 0 0 1 0 6H9" />`;
