// Auto-generated from lucide-static — do not edit
export const checkCheck = `<path d="M18 6 7 17l-5-5" />
<path d="m22 10-7.5 7.5L13 16" />`;
