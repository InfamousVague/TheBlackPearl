// Auto-generated from lucide-static — do not edit
export const appWindow = `<rect x="2" y="4" width="20" height="16" rx="2" />
<path d="M10 4v4" />
<path d="M2 8h20" />
<path d="M6 4v4" />`;
