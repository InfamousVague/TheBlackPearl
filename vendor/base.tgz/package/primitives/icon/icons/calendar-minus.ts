// Auto-generated from lucide-static — do not edit
export const calendarMinus = `<path d="M16 19h6" />
<path d="M16 2v4" />
<path d="M21 15V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h8.5" />
<path d="M3 10h18" />
<path d="M8 2v4" />`;
