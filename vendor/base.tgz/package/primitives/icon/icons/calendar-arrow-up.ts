// Auto-generated from lucide-static — do not edit
export const calendarArrowUp = `<path d="m14 18 4-4 4 4" />
<path d="M16 2v4" />
<path d="M18 22v-8" />
<path d="M21 11.343V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h9" />
<path d="M3 10h18" />
<path d="M8 2v4" />`;
