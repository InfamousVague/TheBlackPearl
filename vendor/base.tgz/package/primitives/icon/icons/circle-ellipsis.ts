// Auto-generated from lucide-static — do not edit
export const circleEllipsis = `<circle cx="12" cy="12" r="10" />
<path d="M17 12h.01" />
<path d="M12 12h.01" />
<path d="M7 12h.01" />`;
