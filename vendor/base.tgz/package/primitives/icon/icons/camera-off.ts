// Auto-generated from lucide-static — do not edit
export const cameraOff = `<path d="M14.564 14.558a3 3 0 1 1-4.122-4.121" />
<path d="m2 2 20 20" />
<path d="M20 20H4a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h1.997a2 2 0 0 0 .819-.175" />
<path d="M9.695 4.024A2 2 0 0 1 10.004 4h3.993a2 2 0 0 1 1.76 1.05l.486.9A2 2 0 0 0 18.003 7H20a2 2 0 0 1 2 2v7.344" />`;
