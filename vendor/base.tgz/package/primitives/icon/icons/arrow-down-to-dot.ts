// Auto-generated from lucide-static — do not edit
export const arrowDownToDot = `<path d="M12 2v14" />
<path d="m19 9-7 7-7-7" />
<circle cx="12" cy="21" r="1" />`;
