// Auto-generated from lucide-static — do not edit
export const battery = `<path d="M 22 14 L 22 10" />
<rect x="2" y="6" width="16" height="12" rx="2" />`;
