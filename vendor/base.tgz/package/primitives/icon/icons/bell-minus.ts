// Auto-generated from lucide-static — do not edit
export const bellMinus = `<path d="M10.268 21a2 2 0 0 0 3.464 0" />
<path d="M15 8h6" />
<path d="M16.243 3.757A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673A9.4 9.4 0 0 1 18.667 12" />`;
