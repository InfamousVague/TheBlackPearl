// Auto-generated from lucide-static — do not edit
export const alignEndVertical = `<rect width="16" height="6" x="2" y="4" rx="2" />
<rect width="9" height="6" x="9" y="14" rx="2" />
<path d="M22 22V2" />`;
