// Auto-generated from lucide-static — do not edit
export const bookUser = `<path d="M15 13a3 3 0 1 0-6 0" />
<path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20" />
<circle cx="12" cy="8" r="2" />`;
