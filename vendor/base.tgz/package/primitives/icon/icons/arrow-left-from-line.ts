// Auto-generated from lucide-static — do not edit
export const arrowLeftFromLine = `<path d="m9 6-6 6 6 6" />
<path d="M3 12h14" />
<path d="M21 19V5" />`;
