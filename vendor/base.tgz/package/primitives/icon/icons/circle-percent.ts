// Auto-generated from lucide-static — do not edit
export const circlePercent = `<circle cx="12" cy="12" r="10" />
<path d="m15 9-6 6" />
<path d="M9 9h.01" />
<path d="M15 15h.01" />`;
