// Auto-generated from lucide-static — do not edit
export const calendarFold = `<path d="M3 20a2 2 0 0 0 2 2h10a2.4 2.4 0 0 0 1.706-.706l3.588-3.588A2.4 2.4 0 0 0 21 16V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2z" />
<path d="M15 22v-5a1 1 0 0 1 1-1h5" />
<path d="M8 2v4" />
<path d="M16 2v4" />
<path d="M3 10h18" />`;
