// Auto-generated from lucide-static — do not edit
export const alignStartVertical = `<rect width="9" height="6" x="6" y="14" rx="2" />
<rect width="16" height="6" x="6" y="4" rx="2" />
<path d="M2 2v20" />`;
