// Auto-generated from lucide-static — do not edit
export const chevronsLeftRight = `<path d="m9 7-5 5 5 5" />
<path d="m15 7 5 5-5 5" />`;
