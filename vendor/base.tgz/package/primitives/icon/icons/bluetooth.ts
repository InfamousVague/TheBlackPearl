// Auto-generated from lucide-static — do not edit
export const bluetooth = `<path d="m7 7 10 10-5 5V2l5 5L7 17" />`;
