// Auto-generated from lucide-static — do not edit
export const betweenHorizontalStart = `<rect width="13" height="7" x="8" y="3" rx="1" />
<path d="m2 9 3 3-3 3" />
<rect width="13" height="7" x="8" y="14" rx="1" />`;
