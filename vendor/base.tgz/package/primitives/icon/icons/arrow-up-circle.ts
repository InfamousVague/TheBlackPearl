// Auto-generated from lucide-static — do not edit
export const arrowUpCircle = `<circle cx="12" cy="12" r="10" />
<path d="m16 12-4-4-4 4" />
<path d="M12 16V8" />`;
