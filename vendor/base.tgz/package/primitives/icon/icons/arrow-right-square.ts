// Auto-generated from lucide-static — do not edit
export const arrowRightSquare = `<rect width="18" height="18" x="3" y="3" rx="2" />
<path d="M8 12h8" />
<path d="m12 16 4-4-4-4" />`;
