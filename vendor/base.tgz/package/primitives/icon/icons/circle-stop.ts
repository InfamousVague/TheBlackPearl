// Auto-generated from lucide-static — do not edit
export const circleStop = `<circle cx="12" cy="12" r="10" />
<rect x="9" y="9" width="6" height="6" rx="1" />`;
