// Auto-generated from lucide-static — do not edit
export const arrowDownLeftFromCircle = `<path d="M2 12a10 10 0 1 1 10 10" />
<path d="m2 22 10-10" />
<path d="M8 22H2v-6" />`;
