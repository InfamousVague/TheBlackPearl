// Auto-generated from lucide-static — do not edit
export const appWindowMac = `<rect width="20" height="16" x="2" y="4" rx="2" />
<path d="M6 8h.01" />
<path d="M10 8h.01" />
<path d="M14 8h.01" />`;
