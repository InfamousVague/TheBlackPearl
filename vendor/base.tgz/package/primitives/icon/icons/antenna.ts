// Auto-generated from lucide-static — do not edit
export const antenna = `<path d="M2 12 7 2" />
<path d="m7 12 5-10" />
<path d="m12 12 5-10" />
<path d="m17 12 5-10" />
<path d="M4.5 7h15" />
<path d="M12 16v6" />`;
