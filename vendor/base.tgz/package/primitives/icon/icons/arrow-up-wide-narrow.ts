// Auto-generated from lucide-static — do not edit
export const arrowUpWideNarrow = `<path d="m3 8 4-4 4 4" />
<path d="M7 4v16" />
<path d="M11 12h10" />
<path d="M11 16h7" />
<path d="M11 20h4" />`;
