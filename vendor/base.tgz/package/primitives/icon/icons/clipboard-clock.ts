// Auto-generated from lucide-static — do not edit
export const clipboardClock = `<path d="M16 14v2.2l1.6 1" />
<path d="M16 4h2a2 2 0 0 1 2 2v.832" />
<path d="M8 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h2" />
<circle cx="16" cy="16" r="6" />
<rect x="8" y="2" width="8" height="4" rx="1" />`;
