// Auto-generated from lucide-static — do not edit
export const clock2 = `<circle cx="12" cy="12" r="10" />
<path d="M12 6v6l4-2" />`;
