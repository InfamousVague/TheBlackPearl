// Auto-generated from lucide-static — do not edit
export const circleChevronDown = `<circle cx="12" cy="12" r="10" />
<path d="m16 10-4 4-4-4" />`;
