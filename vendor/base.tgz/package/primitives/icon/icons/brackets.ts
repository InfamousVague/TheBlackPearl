// Auto-generated from lucide-static — do not edit
export const brackets = `<path d="M16 3h3a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1h-3" />
<path d="M8 21H5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h3" />`;
