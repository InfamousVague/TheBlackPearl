// Auto-generated from lucide-static — do not edit
export const chevronsUp = `<path d="m17 11-5-5-5 5" />
<path d="m17 18-5-5-5 5" />`;
